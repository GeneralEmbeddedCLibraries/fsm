var structfsm__s =
[
    [ "duration", "structfsm__s.html#a723ca2a29f25522eef6fe49af9843d8a", null ],
    [ "first_entry", "structfsm__s.html#af4d7f0e21fadfd688667432410db007a", null ],
    [ "is_init", "structfsm__s.html#a9f333e33907ac1a82a2c5be69bf6674f", null ],
    [ "p_cfg", "structfsm__s.html#ac4eb82eaa411492b00079122654a6c7a", null ],
    [ "state", "structfsm__s.html#aab066c15f37c82fab097354de04875f4", null ]
];