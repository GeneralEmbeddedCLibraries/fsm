var structfsm__cfg__t =
[
    [ "name", "structfsm__cfg__t.html#a1194e0573cb9da897583a17853ec7a04", null ],
    [ "num_of", "structfsm__cfg__t.html#aafea0dd6497f17361641c60c9478ceb4", null ],
    [ "period", "structfsm__cfg__t.html#a34239b95af5e1986951cbe3389cf58f3", null ],
    [ "state", "structfsm__cfg__t.html#a93909cc09cd43608bc605ed044b6cc2d", null ]
];